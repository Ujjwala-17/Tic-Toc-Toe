(() => {
"use strict";
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const storeKey="pardhus_ttt_history_v2";
let soundOn=true,audioCtx=null, musicGain=null, musicTimer=null, musicStep=0, mode="ai",difficulty="medium",myMark="X",size=3,winTarget=3;
let board=[],turn="X",gameOver=false,startedAt=0,timerId=null,lastMove=-1;
let localWins={X:0,O:0}, onlineRole=null, peer=null, conn=null, roomCode="";
let friend1Name="Player 1", friend2Name="Player 2";
const home=$("#home"),setup=$("#setup"),game=$("#game"),boardEl=$("#board"),toastEl=$("#toast");
function go(screen){[home,setup,game].forEach(x=>x.classList.remove("active"));screen.classList.add("active")}
function ensureAudio(){
 try{const bg=document.getElementById("bgMusic");if(bg)bg.volume=.20;return true}catch{return false}
}
function beep(type="tap"){
 if(!soundOn)return;
 try{const ctx=new (window.AudioContext||window.webkitAudioContext)(),o=ctx.createOscillator(),g=ctx.createGain();const f={tap:520,win:740,lose:170,draw:330}[type]||420;o.frequency.value=f;o.type=type==="win"?"sine":"triangle";g.gain.setValueAtTime(.0001,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.045,ctx.currentTime+.01);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.14);o.connect(g);g.connect(ctx.destination);o.start();o.stop(ctx.currentTime+.15)}catch{}
}
function startMusic(){if(!soundOn)return;const bg=document.getElementById("bgMusic");if(!bg)return;bg.volume=.20;const p=bg.play();if(p&&p.catch)p.catch(()=>{})}
function stopMusic(){const bg=document.getElementById("bgMusic");if(bg){bg.pause();bg.currentTime=0}}
function resumeMusic(){startMusic()}
function toast(msg){toastEl.textContent=msg;toastEl.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>toastEl.classList.remove("show"),2200)}
function history(){try{return JSON.parse(localStorage.getItem(storeKey)||"[]")}catch{return[]}}
function saveResult(result){
 const h=history();h.unshift({date:new Date().toLocaleString(),mode, size, target:winTarget,result,time:$("#timer").textContent});
 localStorage.setItem(storeKey,JSON.stringify(h.slice(0,50)));refreshStats();
}
function refreshStats(){
 const h=history(),wins=h.filter(x=>x.result==="WIN").length;
 $("#statWins").textContent=wins;$("#statGames").textContent=h.length;
 let streak=0; for(const x of h){if(x.result==="WIN")streak++;else break} $("#statStreak").textContent=streak;
}
function renderHistory(){
 const h=history();$("#historyList").innerHTML=h.length?h.map(x=>`<div class="history-item"><b>${x.result}</b><span>${x.mode.toUpperCase()} · ${x.size}×${x.size} · ${x.target} · ${x.time}</span></div>`).join(""):"<p class='tip'>No matches yet. Your future victories will appear here.</p>";
}
$("#historyBtn").onclick=()=>{$("#historyModal").classList.add("show");renderHistory()};$("#historyClose").onclick=()=>$("#historyModal").classList.remove("show");
$("#clearHistory").onclick=()=>{localStorage.removeItem(storeKey);refreshStats();renderHistory();toast("History cleared")};
$("#soundToggle").onclick=()=>{
 soundOn=!soundOn;$("#soundToggle").textContent=soundOn?"🔊":"🔇";
 if(soundOn) resumeMusic(); else stopMusic();
};
$("#soundHint").onclick=()=>{$("#soundToggle").click()};
window.addEventListener("pointerdown",()=>{if(soundOn)startMusic()},{once:false,passive:true});
$$(".mode-card").forEach(b=>b.onclick=()=>{
 if(soundOn)startMusic();
 mode=b.dataset.mode; $("#aiSettings").classList.toggle("hidden",mode!=="ai");$("#onlineSettings").classList.toggle("hidden",mode!=="online");
 $("#friendSettings").classList.toggle("hidden",mode!=="local");
 $("#setupTitle").textContent=mode==="ai"?"Build your AI match":mode==="local"?"Build your friend match":"Create your online arena";
 $("#setupEyebrow").textContent=mode==="online"?"LIVE NETWORK":"GAME SETUP"; $("#setupStatus").textContent="";
 go(setup);
});
$("#setupBack").onclick=()=>go(home);$("#gameBack").onclick=()=>{stopTimer();cleanupPeer();go(home)};
$("#boardSize").oninput=e=>{size=+e.target.value;$("#sizeValue").textContent=`${size} × ${size}`;if(winTarget>size)winTarget=size;$("#winTarget").value=Math.min(5,winTarget);$("#winValue").textContent=`${winTarget} in a row`};
$("#winTarget").oninput=e=>{winTarget=Math.min(+e.target.value,size);e.target.value=winTarget;$("#winValue").textContent=`${winTarget} in a row`};
$$("[data-diff]").forEach(b=>b.onclick=()=>{$$("[data-diff]").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");difficulty=b.dataset.diff});
$$("[data-mark]").forEach(b=>b.onclick=()=>{$$("[data-mark]").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");myMark=b.dataset.mark});
function resetBoard(){board=Array(size*size).fill("");turn="X";gameOver=false;lastMove=-1;renderBoard();updateTurn();$("#roundText").textContent=`${size}×${size} ARENA`;$("#boardTip").textContent=`Get ${winTarget} in a row to win.`}
function renderBoard(){
 boardEl.style.gridTemplateColumns=`repeat(${size},var(--cell))`;boardEl.innerHTML="";
 board.forEach((v,i)=>{const c=document.createElement("button");c.className="cell"+(v?" filled "+v.toLowerCase():"")+(i===lastMove?" last":"");c.textContent=v;c.setAttribute("aria-label",`Cell ${i+1}`);c.onclick=()=>play(i);boardEl.appendChild(c)});
}
function updateTurn(){
 const your=(mode==="ai"&&turn===myMark)||(mode==="local")||(mode==="online"&&((onlineRole==="host"&&turn==="X")||(onlineRole==="guest"&&turn==="O")));
 $("#turnText").textContent=gameOver?"Match complete":(your?"Your turn":`${turn}'s turn`);
 $("#p1").classList.toggle("active",turn==="X");$("#p2").classList.toggle("active",turn==="O");
}
function checkWin(b=board,player=turn){
 const dirs=[[1,0],[0,1],[1,1],[1,-1]];
 for(let r=0;r<size;r++)for(let c=0;c<size;c++){if(b[r*size+c]!==player)continue;
  for(const [dr,dc] of dirs){let cells=[[r,c]],rr=r+dr,cc=c+dc;while(rr>=0&&rr<size&&cc>=0&&cc<size&&b[rr*size+cc]===player){cells.push([rr,cc]);rr+=dr;cc+=dc}
   if(cells.length>=winTarget)return cells;
  }
 }return null;
}
function boardFull(){return board.every(Boolean)}
function play(i,remote=false){
 if(gameOver||board[i])return;
 const allowed= mode==="local" || (mode==="ai"&&turn===myMark) || (mode==="online"&&((onlineRole==="host"&&turn==="X")||(onlineRole==="guest"&&turn==="O")));
 if(!allowed)return;
 board[i]=turn;lastMove=i;beep("tap");renderBoard();
 if(mode==="online"&&!remote) send({type:"move",index:i});
 const win=checkWin(board,turn); if(win)return finish(turn,win);
 if(boardFull())return finish("DRAW");
 turn=turn==="X"?"O":"X";updateTurn();
 if(mode==="ai"&&turn!==myMark&&!gameOver)setTimeout(aiMove,250);
}
function finish(winner,cells){
 gameOver=true;stopTimer();updateTurn();
 if(cells){cells.forEach(([r,c])=>boardEl.children[r*size+c].classList.add("win"))}
 const you=winner==="DRAW"?"DRAW":((mode==="ai"&&winner===myMark)||(mode==="local"&&winner==="X")||(mode==="online"&&((onlineRole==="host"&&winner==="X")||(onlineRole==="guest"&&winner==="O"))));
 const result=winner==="DRAW"?"DRAW":you?"WIN":"LOSS";saveResult(result);
 if(mode==="online")send({type:"finish",winner,cells});
 $("#resultIcon").textContent=result==="WIN"?"✦":result==="DRAW"?"◇":"×";
 const winnerName = winner==="X" ? $("#p1Name").textContent : $("#p2Name").textContent;
 $("#resultTitle").textContent=winner==="DRAW"?"Draw":`${winnerName} wins!`;
 $("#resultText").textContent=winner==="DRAW"?"No winner this round — the board is perfectly balanced.":"Congratulations, "+winnerName+"! That was a winning line.";
 $("#resultModal").classList.add("show");beep(result==="WIN"?"win":result==="DRAW"?"draw":"lose");
}
function aiMove(){
 if(gameOver || mode!=="ai" || turn===myMark)return;
 const ai=turn,human=myMark,empty=board.map((v,i)=>v?null:i).filter(i=>i!==null);
 if(!empty.length)return;
 let move=null;
 for(const i of empty){board[i]=ai;if(checkWin(board,ai)){board[i]="";move=i;break}board[i]=""}
 if(move===null)for(const i of empty){board[i]=human;if(checkWin(board,human)){board[i]="";move=i;break}board[i]=""}
 if(move===null){
  if(size===3){
   if(!board[4])move=4;
   else{const corners=[0,2,6,8].filter(i=>!board[i]);move=corners.length?corners[Math.floor(Math.random()*corners.length)]:empty[Math.floor(Math.random()*empty.length)]}
  }else{
   let best=-Infinity;
   for(const i of empty){const r=Math.floor(i/size),c=i%size;let score=Math.random()*2;score+=(size/2-Math.abs(r-(size-1)/2))*2+(size/2-Math.abs(c-(size-1)/2))*2;board[i]=ai;score+=evaluatePoint(i,ai)*3;board[i]="";board[i]=human;score+=evaluatePoint(i,human)*2;board[i]="";if(score>best){best=score;move=i}}
  }
 }
 if(move===null||board[move])move=empty[0];
 setTimeout(()=>{if(!gameOver&&mode==="ai"&&turn===ai&&!board[move])play(move)},350);
}
function evaluatePoint(i,p){
 const r=Math.floor(i/size),c=i%size;let total=0;
 for(const [dr,dc] of [[1,0],[0,1],[1,1],[1,-1]]){let n=1;for(const s of [-1,1]){let rr=r+dr*s,cc=c+dc*s;while(rr>=0&&rr<size&&cc>=0&&cc<size&&board[rr*size+cc]===p){n++;rr+=dr*s;cc+=dc*s}}total+=n*n}return total;
}
function startGame(){
 $("#resultModal").classList.remove("show");onlineRole=null;cleanupPeer();
 friend1Name=($("#friend1Name")?.value.trim()||"Player 1").slice(0,18);
 friend2Name=($("#friend2Name")?.value.trim()||"Player 2").slice(0,18);
 resetBoard();startedAt=Date.now();startTimer();
 $("#gameModeLabel").textContent=mode==="ai"?"AI MATCH":mode==="local"?"LOCAL MATCH":"ONLINE MATCH";
 $("#p1Name").textContent=mode==="ai"?(myMark==="X"?"YOU":"AI"):(mode==="online"?"HOST":friend1Name);
 $("#p2Name").textContent=mode==="ai"?(myMark==="O"?"YOU":"AI"):(mode==="online"?"GUEST":friend2Name);
 $("#p1Score").textContent="0 wins";$("#p2Score").textContent="0 wins";go(game);
 if(mode==="ai"&&myMark==="O")setTimeout(aiMove,400);
}
$("#startGame").onclick=startGame;$("#restart").onclick=()=>{resetBoard();startedAt=Date.now();startTimer();if(mode==="ai"&&myMark==="O")setTimeout(aiMove,300)};
$("#again").onclick=()=>{$("#resultModal").classList.remove("show");resetBoard();startedAt=Date.now();startTimer();if(mode==="ai"&&myMark==="O")setTimeout(aiMove,300)};
$("#homeBtn").onclick=()=>{$("#resultModal").classList.remove("show");stopTimer();cleanupPeer();go(home)};
function startTimer(){stopTimer();timerId=setInterval(()=>{const s=Math.floor((Date.now()-startedAt)/1000);$("#timer").textContent=`${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`},1000)}
function stopTimer(){clearInterval(timerId);timerId=null}
function cleanupPeer(){if(conn){try{conn.close()}catch{}}if(peer){try{peer.destroy()}catch{}}conn=null;peer=null;onlineRole=null}
function makeCode(){return Math.random().toString(36).slice(2,8).toUpperCase()}
function setupPeer(role){
 roomCode=($("#roomCode").value.trim()||makeCode()).toUpperCase();$("#roomCode").value=roomCode;onlineRole=role;
 if(typeof Peer==="undefined"){toast("Online engine failed to load");return}
 const id="vx-ttt-"+roomCode.toLowerCase(); peer=new Peer(id,{debug:0});
 peer.on("open",()=>{$("#setupStatus").textContent=role==="host"?`Room ${roomCode} is live. Share the code with your friend.`:`Waiting for room ${roomCode}…`});
 peer.on("error",e=>{$("#setupStatus").textContent=e.type==="unavailable-id"?"Room code already in use. Try another code.":`Network: ${e.type}`;toast("Online connection error")});
 peer.on("connection",c=>{if(role!=="host")return;attachConnection(c);toast("Friend connected!");$("#setupStatus").textContent="Friend connected. Launch the match.";});
 if(role==="guest"){const c=peer.connect(id,{reliable:true});attachConnection(c);c.on("open",()=>{send({type:"hello",size,winTarget,name:friend2Name});$("#setupStatus").textContent="Connected to host. Launching…";setTimeout(()=>{$("#startGame").click()},500)})}
}
function attachConnection(c){conn=c;c.on("data",handleNet);c.on("close",()=>toast("Friend disconnected"));c.on("error",()=>toast("Connection lost"))}
function send(msg){if(conn&&conn.open)conn.send(msg)}
function handleNet(m){
 if(m.type==="move"){if(game.classList.contains("active"))play(m.index,true)}
 if(m.type==="hello"){size=m.size;winTarget=Math.min(m.winTarget,size);
  if(m.name) friend2Name=m.name;$("#boardSize").value=size;$("#winTarget").value=winTarget;resetBoard();send({type:"state",board,turn,size,winTarget});startGame()}
 if(m.type==="state"){size=m.size;winTarget=m.winTarget;board=[...m.board];turn=m.turn;renderBoard();updateTurn()}
 if(m.type==="finish"){gameOver=true;stopTimer();if(m.cells)m.cells.forEach(([r,c])=>boardEl.children[r*size+c].classList.add("win"));const remoteWinner = m.winner==="DRAW" ? "Draw" : (m.winner==="X" ? $("#p1Name").textContent : $("#p2Name").textContent);
 $("#resultTitle").textContent=m.winner==="DRAW"?"Draw":`${remoteWinner} wins!`;
 $("#resultText").textContent=m.winner==="DRAW"?"No winner this round.":"Congratulations, "+remoteWinner+"! Online match complete.";$("#resultModal").classList.add("show")}
}
$("#createRoom").onclick=()=>{mode="online";setupPeer("host")};
$("#joinRoom").onclick=()=>{mode="online";const code=$("#roomCode").value.trim();if(code.length<4){toast("Enter a room code first");return}setupPeer("guest")};
refreshStats();$("#sizeValue").textContent="3 × 3";$("#winValue").textContent="3 in a row";
})();