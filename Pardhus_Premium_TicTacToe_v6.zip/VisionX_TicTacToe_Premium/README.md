# Pardhu's — Premium Tic Tac Toe

A complete browser-based rebuild with:
- Single Player vs adaptive AI
- Play With Friends (same device)
- Online Multiplayer rooms using PeerJS
- 2×2 through 20×20 boards
- Configurable 2–5 win target
- Local score/history in localStorage
- Premium responsive UI, motion, glow effects and WebAudio
- No build step required

## Run
Open `index.html` in a browser or use VS Code Live Server.

## Deploy
Upload these three files to your existing static hosting:
- index.html
- style.css
- script.js

For online multiplayer, the site must be served over HTTPS (or localhost). PeerJS provides the signaling connection; no private API key is required.

## Notes
This version intentionally replaces the old Tic-Tac-Toe frontend rather than preserving the old UI.

## Friend names & winner screen
- Play With Friends asks for Friend 1 and Friend 2 names before the match.
- Names can be edited before every new match.
- The result screen clearly shows which named player won, or Draw.

## AI move reliability
- AI checks winning moves and blocks threats first.
- 3×3 uses minimax; larger boards use the fast heuristic engine.
- A safe fallback guarantees an AI move when empty cells remain.
